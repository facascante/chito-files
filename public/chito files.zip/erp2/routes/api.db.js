var fs = require('fs');
var model = require('../models/core.db.mongo.js');

exports.list = function(req, res){
	model.GetAllObjects(req,function(result){		
		res.json(result);
	});	
};

exports.custom = function(req, res){
	model.GetCustomObjects(req,function(result){		
		res.json(result);
	});	
};

exports.filtered = function(req, res){
	model.GetFilteredObjects(req,function(result){		
		res.json(result);
	});	
};

exports.findOne = function(req, res){
	model.GetObject(req,function(result){		
		res.json(result);
	});	
};

exports.create = function(req, res){	
	console.log(req.files);
	if((!isObjectEmpty(req.body))){
		model.CreateObject(req,function(result){	
			res.json(result,201);
		});
	}
	else{
		res.json(null,405);	
	}
};

exports.update = function(req, res){

	if((!isObjectEmpty(req.body))){
		model.UpdateObject(req,function(result){
			res.json(null,result ? 200 : 404);
		});
	}
	else{		
		res.json(null,405);
	}
};

exports.remove = function(req, res){	
	model.RemoveObject(req,function(result){		
		res.json(result ? "OK" : "NOK",result ? 200 : 404);
	});
};

exports.findById = function(id,fn){	
	var req = {params:{object:"users",ref:'id',val:id},query:{skip:0,limit:0}};
	model.GetFilteredObjects(req,function(user){
		if(user.length > 0){
			if (user[0]) {
			    fn(null, user[0]);
			 } else {
			    fn(new Error('User ' + id + ' does not exist'));
			 }
		}
		else{
			fn(new Error('User ' + id + ' does not exist'));
		}
	});	 
};

exports.findByUsername = function(username,fn){	
	var req = {params:{object:"users",ref:'username',val:username},query:{skip:0,limit:0}};
	model.GetFilteredObjects(req,function(user){
		if(user.length > 0){
			if (user[0].username === username) {
			      return fn(null, user[0]);
			}
		}
		else{
			return fn(null, null);
		}
		
	});	 
};

exports.ensureAuthenticated = function(req, res, next) {
	  if (req.isAuthenticated()) { return next(); }
	  res.redirect('/login');
};

exports.updateLogin = function(userId,res){
	
	var new_date = new Date();
	req = {params:{object:"users",id:userId},body:{}};
	req.body["$set"] = {last_login:new_date.toLocaleString()}
	model.UpdateObject(req,function(result){
			res(null,result ? 200 : 404);
	});
	

	
};

function dirExistsSync (d) {
	  try { fs.statSync(d).isDirectory(); }
	  catch (er) { return false; }
}

function isObjectEmpty(object)
{
  var isEmpty = true;
  for(keys in object)
  {
     isEmpty = false;     
     break;
  }
  
  return isEmpty;
}
