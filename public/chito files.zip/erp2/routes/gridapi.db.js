var async = require('async');
var lib = require('../lib/griddb.js');
var inventory = require('../lib/inventory.js');
var stocks = require('../lib/stocks.js');

exports.list = function(req, res){
	lib.GridData(req,function(result){		
		res.json(result);
	});	
};
exports.subgridList = function(req, res){
	lib.SubGridData(req,function(result){	
	
		res.json(result);
	});	
};

exports.provision = function(req, res){
	var operation = req.body.oper;
	async.auto({
	    validate: function(callback){
	 
	    	stocks.manipulate(req,function(error,result){   
	    		if(result){
	    			callback(null,result);
	    		}
	    		else{
	    			callback(error);
	    		}
	    	});
	        
	    },
	    provision: ['validate', function(callback,results){

	    	lib.Provision(req,function(result){	   		
	    		callback(null,result);
	    	});	
	    }]
	},
	function(err, results) {	
		if(results && results.validate){
			console.log(results.provision);
			req.params.id = results.provision[2];
			if(operation == "del"){
				res.json(results.provision);
			}
			else{
				lib.getComputedFields(req,req.params.object,req.params.section,req.params.id,function(error,result){
					res.json(results.provision);
				});
				
			}
		}
		else{
			res.json(404,err);
		}
	
	});
	
};

exports.subgridprovision = function(req, res){
	var operation = req.body.oper;
	async.auto({
		provision: function(callback){
	    	lib.SubGridProvision(req,function(result){	   
	    		callback(null,result);	
	    	});	
	    }
	},
	function(err, results) {	
		
			if(operation == "del"){
				res.json(results.provision);
			}
			else{
				lib.getComputedFields(req,req.params.object,req.params.section,req.params.id,function(error,result){
					res.json(results.provision);
				});
				
			}
	
	});
};

exports.upload = function(req, res){
	lib.Upload(req,function(result){
		
		res.json(result);
	});
};



