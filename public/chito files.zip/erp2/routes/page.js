navigation = require('../lib/navigation.js');
gridDb = require('../lib/gridDb.js');
var async = require('async');
var navItems;
navigation.showNavigation(function(result){
	navItems = result;
});



exports.home = function(req, res){
	navigation.showNavigation(function(result){
		navItems = result;
		res.render('index', { title: 'Home Dashboard', 
				file:'index', user: req.user, 
				navigation: navItems , 
				message: {error: req.flash('error'), info: req.flash('info')}});
	});

};

exports.login = function(req, res){
	  res.render('login', { title: 'User Sign In', 
		  					file:'login', 
		  					user: req.user, 
		  					navigation: navItems , 
		  					message: {error: req.flash('error'), info: req.flash('info')}});
};

exports.object = function(req, res){
		
		gridDb.GridSetting(req,function(result){	
			
			res.render("template/settings" , {
					file:req.params.val + "/" +req.params.section ,
					
					title: ucFirstAllWords("Manage "+req.params.val + " " + req.params.section),
					user: req.user, 
					navigation: navItems , 
					gridSetting: result,
					message: {error: req.flash('error'), info: req.flash('info')}});
		});
		
	
	  
};

function ucFirstAllWords( str )
{
    var pieces = str.split(" ");
    for ( var i = 0; i < pieces.length; i++ )
    {
        var j = pieces[i].charAt(0).toUpperCase();
        pieces[i] = j + pieces[i].substr(1);
    }
    return pieces.join(" ");
}
