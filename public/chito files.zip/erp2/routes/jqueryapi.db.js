
var lib = require('../lib/jquerydb.js');

exports.chain = function(req, res){
	lib.ChainSelect(req,function(result){		
		res.json(result);
	});	
};
