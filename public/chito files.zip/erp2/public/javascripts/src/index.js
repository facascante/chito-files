
$(document).ready(function(){	
	
	$( "#login" ).button({
        icons: {
            primary: "ui-icon-key"
        }
    });
});
