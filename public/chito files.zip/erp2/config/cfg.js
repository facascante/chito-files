

exports.GetDBSchema = function(){	

	return "erp";
};

exports.GetDB = function(){	
	 
	return "mongodb://localhost/";
};

exports.AppMessage = function(){	
	
	app_msg = {
			
			"DB0001":{"ERROR":"No Database Connection"}
	};
	return app_msg;
};
exports.gridDataUrl = function(table,page){
	
		return "/api/grid/"+table+"/"+page;
	
};
exports.gridProvUrl = function(table,page){
	
	return "/api/grid/"+table+"/"+page;

};

