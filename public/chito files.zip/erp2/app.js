
/**
 * Module dependencies.
 */

var express = require('express')
  , page = require('./routes/page')
  , passport = require('passport')
  , dbapi = require('./routes/api.db')
  , gridapi = require('./routes/gridapi.db')
  , jqueryapi = require('./routes/jqueryapi.db')
  , flash = require('connect-flash')
  , crypto = require('crypto')
  , LocalStrategy = require('passport-local').Strategy
  , http = require('http')
  , path = require('path');

passport.serializeUser(function(user, done) {
	  done(null, user.id);
	});

passport.deserializeUser(function(id, done) {
	dbapi.findById(id, function (err, user) {
		if(user){
			delete user.password;
		}
	    done(err, user);
	  });
});

passport.use(new LocalStrategy(
		  function(username, password, done) {		   
		    process.nextTick(function () {		      
		    	dbapi.findByUsername(username, function(err, user) {
		        if (err) { return done(err); }
		        if (!user) { return done(null, false, { message: 'Unknown user ' + username }); }
		        if (user.password != password) { return done(null, false, { message: 'Invalid password' }); }
		        if (user.status != "Active") { return done(null, false, { message: 'Account is ' + user.status }); }
		        delete user.password;
		        dbapi.updateLogin(user.id,function(res){});
		        
		        return done(null, user);
		      });
		    });
		  }
));

var app = express();

app.configure(function(){
  app.set('port', process.env.PORT || 3000);
  app.set('views', __dirname + '/views');
  app.set('view engine', 'ejs');
  app.use(express.favicon());
  app.use(express.compress());
  app.use(express.bodyParser({uploadDir:'public/uploads'}));
  app.use(express.methodOverride());
  app.use(express.cookieParser('erp-blpi'));
  app.use(express.session());
  app.use(flash());
  app.use(passport.initialize());
  app.use(passport.session());
  app.use(express.static(path.join(__dirname, 'public')));
  app.use(express.logger());
  app.use(app.router);
});

app.configure('development', function(){
  app.use(express.errorHandler());
});

// Web Pages
app.get('/',dbapi.ensureAuthenticated, page.home);
app.get('/login', page.login);

app.get('/page/:object/:section',dbapi.ensureAuthenticated, page.object);
app.post('/login',
		  passport.authenticate('local', { failureRedirect: '/login', failureFlash: true }),
		  function(req, res) {
		    res.redirect('/');
});

app.get('/logout', function(req, res){
	  req.logout();
	  res.redirect('/login');
});

//Grid API
app.post('/api/grid/prov/:object/:section',dbapi.ensureAuthenticated,gridapi.provision);
app.post('/api/grid/upload/:object/:section/:attribute/:id',dbapi.ensureAuthenticated,gridapi.upload);
app.post('/api/grid/:object/:section',dbapi.ensureAuthenticated,gridapi.list);
app.post('/api/subgrid/:object/:section/:container',dbapi.ensureAuthenticated,gridapi.subgridList);
app.post('/api/subgrid/prov/:object/:section/:container/:id',dbapi.ensureAuthenticated,gridapi.subgridprovision);

//jquery API
app.get('/api/chain/:object/:column',dbapi.ensureAuthenticated,jqueryapi.chain);

//Web API
app.get('/api/:object',dbapi.ensureAuthenticated,dbapi.list);
app.post('/api/:object',dbapi.ensureAuthenticated,dbapi.create);
app.get('/api/:object/:ref/:val',dbapi.ensureAuthenticated,dbapi.filtered);
app.get('/api/:object/:id',dbapi.ensureAuthenticated,dbapi.findOne);
app.put('/api/:object/:id',dbapi.ensureAuthenticated,dbapi.update);
app.del('/api/:object/:id',dbapi.ensureAuthenticated,dbapi.remove);
app.post('/api/custom/:object',dbapi.ensureAuthenticated,dbapi.custom);




http.createServer(app).listen(app.get('port'), function(){
  console.log("Express server listening on port " + app.get('port'));
});
