function formatFormula(expr,data){
	expr = expr.replace(/ /g,"");
	for(var i in data){
		var regex = new RegExp(i,"g");
		expr = expr.replace(regex,data[i]);
	}
	return expr;
}
var Calculator = (function(){
	function safe(expr){
		if (/[^\d*-+\/()^%. ]/.test(expr))
			throw "Malformed expression.";
		return expr;
	}
	function calculate(expr) {
		try {
			return eval(expr);
		} catch (e) {
			console.log("Malformed expression.");
		}
	}
	return { calculate: calculate };
})();


//var expression = "( ((unit_price/(1 + vat)) - (discount/100)) * quantity) * vat";
var expression = "((1 - (discount/100))*price*quantity)";
//var expression = "((unit_price/(1 + vat)) - discount)";
var data = {"price":100,"vat":.12,"discount":5,quantity:10};
formula = formatFormula(expression,data);
console.log(formula);
console.log(Calculator.calculate(formula));

