var mongoq = require('mongoq');
var ShortId = require('shortid/index');
var cfg = require('../config/cfg.js');

var db = mongoq(cfg.GetDB() +cfg.GetDBSchema());
var app_msg = cfg.AppMessage();

exports.GetAllObjects = function(req,res){		
	db.collection(req.params.object)
		.find({record_status:1},{_id:0,record_status:0})
		.sort({_id:1}).skip(req.query.skip || 0)
		.limit(req.query.limit || 0).toArray()
		.done(function(ObjectArray) {	
			res(ObjectArray);
		})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
		});

};

exports.CountAllObject = function(req,res){
	db.collection(req.params.object)
	.find({record_status:1},{_id:0,record_status:0})
	.sort({_id:1}).skip(req.query.skip || 0)
	.limit(req.query.limit || 0)
	.count()
	.done(function(ObjectArray) {	
		res(ObjectArray);
	})
	.fail( function( err ) { 
		console.log(err);
		res(app_msg.DB0001);
	
	});
};

exports.CountCustomObject = function(req,res){
	req.body.filter ? req.body.filter.record_status = 1 : req.body.filter = {record_status:1};
	db.collection(req.params.object)
	.find(req.body.filter,{_id:0,record_status:0})
	.sort({_id:1}).skip(req.query.skip || 0)
	.limit(req.query.limit || 0)
	.count()
	.done(function(ObjectArray) {	
		res(ObjectArray);
	})
	.fail( function( err ) { 
		console.log(err);
		res(app_msg.DB0001);
	
	});
};

exports.GetCustomObjects = function(req,res){

	req.body.filter ? req.body.filter.record_status = 1 : req.body.filter = {record_status:1};
	req.body.cols ? req.body.cols._id = 0 : req.body.cols = {_id:0};
	req.body.sort ? req.body.sort : req.body.sort = {};

	db.collection(req.params.object)
		.find(req.body.filter,req.body.cols)
		.sort(req.body.sort).skip(req.query.skip || 0)
		.limit(req.query.limit || 0).toArray()
		.done(function(ObjectArray) {	
			
			res(ObjectArray);
		})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
		});
};

exports.GetFilteredObjects = function(req,res){	
	var key = {record_status:1};
	key[req.params.ref] = req.params.val;	
	req.body ? (req.body.sort ? req.body.sort : req.body.sort = {}) : req.body = {sort:{}};
	req.body.sort ? req.body.sort : req.body.sort = {};
	db.collection(req.params.object)
		.find(key,{_id:0})
		.sort(req.body.sort)
		.skip(req.query.skip || 0)
		.limit(req.query.limit || 0).toArray()
		.done(function(ObjectArray) {		
			res(ObjectArray);
		})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
		});
};

exports.GetObject = function(req,res){	
	
	db.collection(req.params.object)
		.findOne({id : req.params.id},{_id:0,record_status:0})
		.done(function(Object) {	
			res(Object);
    });
};

function isNumeric(n) {
	  return !isNaN(parseFloat(n)) && isFinite(n);
}

exports.GetCustomObject = function(req,res){	
	req.condition.record_status = 1;
	db.collection(req.table)
		.findOne(req.condition,{_id:0,record_status:0})
		.done(function(Object) {	
			res(Object);
    });
};

exports.GetCustomObjectArray = function(req,res){	
	req.condition.record_status = 1;
	db.collection(req.table)
		.find(req.condition,{_id:0,record_status:0})
		.toArray()
		.done(function(Object) {	
			res(Object);
    });
};

exports.CreateObject = function(req,res){	

    var record = req.body; 
    record.id = ShortId.generate();
    record[req.params.section + "_created_on"] = new Date().toLocaleString();
    record[req.params.section + "_created_by"] = req.user.username;
    record.record_status = 1;
	db.collection(req.params.object)
		.insert(record, {safe: true})
		.done(function(Object){   
			res(Object);
		})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
		});	  
};

exports.InsertObjectArray = function(req,res){	
	req.body['id'] = ShortId.generate();
	var record = {};
	record["$push"] = {};
	req.body.created_on = new Date().toLocaleString();
	req.body.created_by =req.user.username;
	record["$push"][req.params.container] = req.body;
	db.collection(req.params.object)
    	.update({id: req.params.id}, record, {safe: true, upsert:true})
    	.done(function(success) {   
    		res(req.body.id);
    	})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
	});
	
    
};

exports.GetObjectArray = function(req,res){	
	var filter = {};
	filter[req.params.container+".id"] = req.body.id;
	var cols = {};
	cols = req.cols;
	cols[req.params.container+".$"] = 1;
	db.collection(req.params.object)
		.findOne(filter,cols)
		.done(function(Object) {	
			res(Object);
    });
};

exports.UpdateObjectArray = function(req,res){	
	var record = {};
	record["$set"] = {};
	req.body.updated_on = new Date().toLocaleString();
	req.body.updated_by = req.user.username;
	for(var i in req.body){
		record["$set"][req.params.container + ".$." + i] = req.body[i];
	}
	
	var filter = {};
	filter[req.params.container + ".id"] = req.body.id ;
	db.collection(req.params.object)
    	.update(filter, record, {safe: true, upsert:true})
    	.done(function(success) {   
    		res(req.body.id);
    	})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
	});
	
    
};

exports.DeleteObjectArrayContent = function(req,res){	
	var record = {};
	record["$pull"] = {};
	record["$pull"][req.params.container] = {id:req.params.id};
	var filter = {};
	filter[req.params.container + ".id"] = req.params.id ;

	db.collection(req.params.object)
    	.update(filter, record, {safe: true, upsert:true})
    	.done(function(success) {   
    		res(success);
    	})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
	});
	
    
};


exports.UpdateObject = function(req,res){	
	var new_date = new Date();
	
	var record = req.body;	
	
	record["$set"][req.params.section + "_updated_on"] = new_date.toLocaleString();
	record["$set"][req.params.section + "_updated_by"] = (req.user && req.user.username)?req.user.username:"";
	if(record["$set"] && !("record_status" in record["$set"])){
		record["$set"].record_status = 1;
		
	}	
	if(req.params.id.split('_')[0] == "dnd"){
		record["$set"][req.params.section + "_created_on"] = new_date.toLocaleString();
		record["$set"][req.params.section + "_created_by"] = (req.user && req.user.username)?req.user.username:"";
		delete record["$set"][req.params.section + "_updated_on"];
		delete record["$set"][req.params.section + "_updated_on"];
		req.params.id = ShortId.generate();
	}
    db.collection(req.params.object)
    	.update({id: req.params.id}, record, {safe: true, upsert:true})
    	.done(function(success) {   
    		res(success);
    	})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
		});
};

exports.RemoveObject = function(req,res){	
	db.collection(req.params.object)
		.remove({id: req.params.id}, {safe: true})
		.done(function(success) {
	    		res(success);
		})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
		});
};

exports.IncrementObject = function(table,res){	

	var record = {"$inc":table.query};	
	
    db.collection(table.name)
    	.update(table.filter, record, {safe: true})
    	.done(function(success) {   
    		res(success);
    	})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
		});
};

exports.SearchAlter = function(req,res){
	
	var filter = req.filter ? req.filter : {};
	var sort = req.sort ? req.filter : {};
	var record = req.body;
	if(record){
		db.collection(req.params.object)
		.findAndModify(filter,sort,record, {safe: true, upsert:true})
		.done(function(success) {
	    		res(success);
		})
		.fail( function( err ) { 
			console.log(err);
			res(app_msg.DB0001);
		
		});
	}
	else{
		res(app_msg.DB0002);
	}
};

